#ifndef CRC32_H_INCLUDED
#define CRC32_H_INCLUDED

unsigned int xcrc32(const unsigned char* buf, int len);

#endif